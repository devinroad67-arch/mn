package skid.gypsyy.mixin;

import skid.gypsyy.DonutBBC;
import skid.gypsyy.event.events.Render3DEvent;
import skid.gypsyy.manager.EventManager;
import skid.gypsyy.module.modules.misc.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
   @Shadow
   @Final
   private Camera camera;

   @Shadow
   protected abstract double getFov(Camera var1, float var2, boolean var3);

   @Shadow
   public abstract Matrix4f getBasicProjectionMatrix(double var1);

   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V",
         ordinal = 1
      )}
   )
   private void onWorldRender(RenderTickCounter rtc, CallbackInfo ci) {
      EventManager.elementCodec(
         new Render3DEvent(new MatrixStack(), this.getBasicProjectionMatrix(this.getFov(this.camera, rtc.getTickDelta(true), true)), rtc.getTickDelta(true))
      );
   }

   @Inject(
      method = {"shouldRenderBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
      if (DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Freecam.class).isEnabled()) {
         cir.setReturnValue(false);
      }
   }
}
