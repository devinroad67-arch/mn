package skid.gypsyy.imixin;

public interface IKeybinding {
   boolean krypton$isActuallyPressed();

   void krypton$resetPressed();
}
