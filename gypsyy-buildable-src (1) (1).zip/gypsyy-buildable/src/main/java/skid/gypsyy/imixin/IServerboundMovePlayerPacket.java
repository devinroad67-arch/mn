package skid.gypsyy.imixin;

public interface IServerboundMovePlayerPacket {
   void setYRot(float var1);

   void setXRot(float var1);

   void setHasRot(boolean var1);
}
