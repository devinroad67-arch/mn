package skid.gypsyy.imixin;

import net.minecraft.util.math.Vec3d;

public interface IExplosion {
   void keyCodec(Vec3d var1, float var2, boolean var3);
}
