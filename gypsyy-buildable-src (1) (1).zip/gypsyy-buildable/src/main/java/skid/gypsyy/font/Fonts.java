package skid.gypsyy.font;

public final class Fonts {
   public static GlyphPageFontRenderer FONT = GlyphPageFontRenderer.init("/font.ttf", 35, false, false, false);
}
