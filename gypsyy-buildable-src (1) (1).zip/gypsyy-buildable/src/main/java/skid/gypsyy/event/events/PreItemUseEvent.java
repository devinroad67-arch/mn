package skid.gypsyy.event.events;

import skid.gypsyy.event.CancellableEvent;

public class PreItemUseEvent extends CancellableEvent {
   public int cooldown;

   public PreItemUseEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
