package skid.gypsyy.event.events;

import skid.gypsyy.event.CancellableEvent;

public class SendMovementPacketsEvent extends CancellableEvent {
}
