package skid.gypsyy.event.events;

import skid.gypsyy.DonutBBC;
import skid.gypsyy.event.CancellableEvent;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.world.chunk.Chunk;

public class ChunkDataEvent extends CancellableEvent {
   public ChunkDataS2CPacket packet;

   public ChunkDataEvent(ChunkDataS2CPacket packet) {
      this.packet = packet;
   }

   public Chunk getChunk() {
      return DonutBBC.mc.world == null ? null : DonutBBC.mc.world.getChunk(this.packet.getChunkX(), this.packet.getChunkZ());
   }
}
