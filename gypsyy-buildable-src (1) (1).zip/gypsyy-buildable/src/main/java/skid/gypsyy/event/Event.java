package skid.gypsyy.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
