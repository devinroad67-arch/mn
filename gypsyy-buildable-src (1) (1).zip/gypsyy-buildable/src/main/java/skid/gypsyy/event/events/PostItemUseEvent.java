package skid.gypsyy.event.events;

import skid.gypsyy.event.CancellableEvent;

public class PostItemUseEvent extends CancellableEvent {
   public int cooldown;

   public PostItemUseEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
