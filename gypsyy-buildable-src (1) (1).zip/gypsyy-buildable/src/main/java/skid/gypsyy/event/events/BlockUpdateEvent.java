package skid.gypsyy.event.events;

public class BlockUpdateEvent {
}
