package skid.gypsyy.event.events;

import skid.gypsyy.event.CancellableEvent;

public class MouseScrolledEvent extends CancellableEvent {
   public double amount;

   public MouseScrolledEvent(double amount) {
      this.amount = amount;
   }
}
