package skid.gypsyy.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.VertexSorter;
import skid.gypsyy.module.modules.client.DonutBBC;
import skid.gypsyy.manager.ShaderManager;
import java.awt.Color;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public final class RenderUtils {
   public static VertexSorter vertexSorter;
   public static boolean rendering3D = true;

   public static Vec3d getCameraPos() {
      return getCamera().getPos();
   }

   public static Camera getCamera() {
      return skid.gypsyy.DonutBBC.mc.getBlockEntityRenderDispatcher().camera;
   }

   public static double deltaTime() {
      double n;
      if (skid.gypsyy.DonutBBC.mc.getCurrentFps() > 0) {
         n = 1.0 / skid.gypsyy.DonutBBC.mc.getCurrentFps();
      } else {
         n = 1.0;
      }

      return n;
   }

   public static float fast(float currentValue, float targetValue, float speed) {
      return (1.0F - MathHelper.clamp((float)(deltaTime() * speed), 0.0F, 1.0F)) * currentValue
         + MathHelper.clamp((float)(deltaTime() * speed), 0.0F, 1.0F) * targetValue;
   }

   public static Vec3d getPlayerLookVec(PlayerEntity playerEntity) {
      float cosYaw = MathHelper.cos(playerEntity.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI);
      float sinYaw = MathHelper.sin(playerEntity.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI);
      float cosPitch = MathHelper.cos(playerEntity.getPitch() * (float) (Math.PI / 180.0));
      return new Vec3d(sinYaw * cosPitch, MathHelper.sin(playerEntity.getPitch() * (float) (Math.PI / 180.0)), cosYaw * cosPitch).normalize();
   }

   public static void unscaledProjection() {
      vertexSorter = RenderSystem.getVertexSorting();
      RenderSystem.setProjectionMatrix(
         new Matrix4f().setOrtho(0.0F, skid.gypsyy.DonutBBC.mc.getWindow().getFramebufferWidth(), skid.gypsyy.DonutBBC.mc.getWindow().getFramebufferHeight(), 0.0F, 1000.0F, 21000.0F),
         VertexSorter.BY_Z
      );
      rendering3D = false;
   }

   public static void drawBox(Vec3d pos, Color color, MatrixStack stack) {
      MinecraftClient mc = MinecraftClient.getInstance();
      Camera camera = mc.gameRenderer.getCamera();
      Vec3d camPos = camera.getPos();
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      float alpha = color.getAlpha() / 255.0F;
      float boxWidth = 0.3F;
      float boxHeight = 1.8F;
      Vec3d start = pos.subtract(camPos);
      float x = (float)start.x;
      float y = (float)start.y;
      float z = (float)start.z;
      stack.push();
      Matrix4f matrix = stack.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      GL11.glDepthFunc(519);
      RenderSystem.disableCull();
      RenderSystem.blendFuncSeparate(770, 771, 1, 0);
      BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      RenderSystem.setShader(GameRenderer::getPositionColorProgram);
      buffer.vertex(matrix, x - boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x + boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y, z - boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z + boxWidth).color(red, green, blue, alpha);
      buffer.vertex(matrix, x - boxWidth, y + boxHeight, z - boxWidth).color(red, green, blue, alpha);
      BufferRenderer.drawWithGlobalProgram(buffer.end());
      RenderSystem.disableBlend();
      GL11.glDepthFunc(515);
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      stack.pop();
   }

   public static void drawLine(Vec3d lastPos, Vec3d pos, Color color, MatrixStack stack) {
      MinecraftClient mc = MinecraftClient.getInstance();
      Camera camera = mc.gameRenderer.getCamera();
      Vec3d camPos = camera.getPos();
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      float alpha = color.getAlpha() / 255.0F;
      stack.push();
      Matrix4f matrix = stack.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      GL11.glDepthFunc(519);
      RenderSystem.disableCull();
      RenderSystem.blendFuncSeparate(770, 771, 1, 0);
      BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
      RenderSystem.setShader(GameRenderer::getPositionColorProgram);
      Vec3d start = lastPos.subtract(camPos);
      float startX = (float)start.x;
      float startY = (float)start.y;
      float startZ = (float)start.z;
      Vec3d end = pos.subtract(camPos);
      float endX = (float)end.x;
      float endY = (float)end.y;
      float endZ = (float)end.z;
      buffer.vertex(matrix, startX, startY, startZ).color(red, green, blue, alpha);
      buffer.vertex(matrix, endX, endY, endZ).color(red, green, blue, alpha);
      BufferRenderer.drawWithGlobalProgram(buffer.end());
      RenderSystem.disableBlend();
      GL11.glDepthFunc(515);
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      stack.pop();
   }

   public static void scaledProjection() {
      RenderSystem.setProjectionMatrix(
         new Matrix4f()
            .setOrtho(
               0.0F,
               (float)(skid.gypsyy.DonutBBC.mc.getWindow().getFramebufferWidth() / skid.gypsyy.DonutBBC.mc.getWindow().getScaleFactor()),
               (float)(skid.gypsyy.DonutBBC.mc.getWindow().getFramebufferHeight() / skid.gypsyy.DonutBBC.mc.getWindow().getScaleFactor()),
               0.0F,
               1000.0F,
               21000.0F
            ),
         vertexSorter
      );
      rendering3D = true;
   }

   public static void renderRoundedQuad(
      MatrixStack matrixStack, Color color, double n, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9
   ) {
      int rgb = color.getRGB();
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(GameRenderer::getPositionColorProgram);
      renderRoundedQuadInternal(
         positionMatrix,
         (rgb >> 16 & 0xFF) / 255.0F,
         (rgb >> 8 & 0xFF) / 255.0F,
         (rgb & 0xFF) / 255.0F,
         (rgb >> 24 & 0xFF) / 255.0F,
         n,
         n2,
         n3,
         n4,
         n5,
         n6,
         n7,
         n8,
         n9
      );
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   private static void setup() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
   }

   private static void cleanup() {
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   public static void renderRoundedQuad(MatrixStack matrixStack, Color color, double n, double n2, double n3, double n4, double n5, double n6) {
      renderRoundedQuad(matrixStack, color, n, n2, n3, n4, n5, n5, n5, n5, n6);
   }

   public static void renderRoundedQuadShader(
      MatrixStack matrixStack,
      Color color,
      double x,
      double y,
      double width,
      double height,
      double topLeft,
      double topRight,
      double bottomRight,
      double bottomLeft,
      double smoothness
   ) {
      if (ShaderManager.isInitialized()) {
         ShaderManager.renderRoundedQuad(
            (float)x,
            (float)y,
            (float)width,
            (float)height,
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F,
            color.getAlpha() / 255.0F,
            (float)topLeft,
            (float)topRight,
            (float)bottomRight,
            (float)bottomLeft
         );
      } else {
         renderRoundedQuad(matrixStack, color, x, y, x + width, y + height, topLeft, topRight, bottomRight, bottomLeft, smoothness);
      }
   }

   public static void renderRoundedQuadShader(
      MatrixStack matrixStack, Color color, double x, double y, double width, double height, double radius, double smoothness
   ) {
      renderRoundedQuadShader(matrixStack, color, x, y, width, height, radius, radius, radius, radius, smoothness);
   }

   public static void renderRoundedOutlineInternal(
      Matrix4f matrix4f,
      float n,
      float n2,
      float n3,
      float n4,
      double n5,
      double n6,
      double n7,
      double n8,
      double n9,
      double n10,
      double n11,
      double n12,
      double n13,
      double n14
   ) {
      BufferBuilder begin = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
      double[][] array = new double[][]{{n7 - n12, n8 - n12, n12}, {n7 - n10, n6 + n10, n10}, {n5 + n9, n6 + n9, n9}, {n5 + n11, n8 - n11, n11}};

      for (int i = 0; i < 4; i++) {
         double[] array2 = array[i];
         double n15 = array2[2];
         double angdeg = i * 90.0;

         while (angdeg < 90.0 + i * 90.0) {
            double radians = Math.toRadians(angdeg);
            double sin = Math.sin((float)radians);
            double n16 = sin * n15;
            double cos = Math.cos((float)radians);
            double n17 = cos * n15;
            begin.vertex(matrix4f, (float)array2[0] + (float)n16, (float)array2[1] + (float)n17, 0.0F).color(n, n2, n3, n4);
            begin.vertex(matrix4f, (float)(array2[0] + (float)n16 + sin * n13), (float)(array2[1] + (float)n17 + cos * n13), 0.0F).color(n, n2, n3, n4);
            angdeg += 90.0 / n14;
         }

         angdeg = Math.toRadians(90.0 + i * 90.0);
         double sin2 = Math.sin((float)angdeg);
         double n18 = sin2 * n15;
         double cos2 = Math.cos((float)angdeg);
         double n19 = cos2 * n15;
         begin.vertex(matrix4f, (float)array2[0] + (float)n18, (float)array2[1] + (float)n19, 0.0F).color(n, n2, n3, n4);
         begin.vertex(matrix4f, (float)(array2[0] + (float)n18 + sin2 * n13), (float)(array2[1] + (float)n19 + cos2 * n13), 0.0F).color(n, n2, n3, n4);
      }

      double[] array3 = array[0];
      double n20 = array3[2];
      begin.vertex(matrix4f, (float)array3[0], (float)array3[1] + (float)n20, 0.0F).color(n, n2, n3, n4);
      begin.vertex(matrix4f, (float)array3[0], (float)(array3[1] + (float)n20 + n13), 0.0F).color(n, n2, n3, n4);
      BufferRenderer.drawWithGlobalProgram(begin.end());
   }

   public static void setScissorRegion(int x, int y, int width, int height) {
      MinecraftClient instance = MinecraftClient.getInstance();
      Screen currentScreen = instance.currentScreen;
      int adjustedY;
      if (instance.currentScreen == null) {
         adjustedY = 0;
      } else {
         adjustedY = currentScreen.height - height;
      }

      double scaleFactor = MinecraftClient.getInstance().getWindow().getScaleFactor();
      GL11.glScissor((int)(x * scaleFactor), (int)(adjustedY * scaleFactor), (int)((width - x) * scaleFactor), (int)((height - y) * scaleFactor));
      GL11.glEnable(3089);
   }

   public static void renderCircle(MatrixStack matrixStack, Color color, double centerX, double centerY, double radius, int segments) {
      int clampedSegments = MathHelper.clamp(segments, 4, 360);
      int rgb = color.getRGB();
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      setup();
      RenderSystem.setShader(GameRenderer::getPositionColorProgram);
      BufferBuilder begin = Tessellator.getInstance().begin(DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < 360; i += Math.min(360 / clampedSegments, 360 - i)) {
         double radians = Math.toRadians(i);
         begin.vertex(positionMatrix, (float)(centerX + Math.sin(radians) * radius), (float)(centerY + Math.cos(radians) * radius), 0.0F)
            .color((rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F, (rgb >> 24 & 0xFF) / 255.0F);
      }

      BufferRenderer.drawWithGlobalProgram(begin.end());
      cleanup();
   }

   public static void renderShaderRect(
      MatrixStack matrixStack, Color color, Color color2, Color color3, Color color4, float n, float n2, float n3, float n4, float n5, float n6
   ) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      BufferBuilder begin = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n - 10.0F, n2 - 10.0F, 0.0F);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n - 10.0F, n2 + n4 + 20.0F, 0.0F);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n + n3 + 20.0F, n2 + n4 + 20.0F, 0.0F);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n + n3 + 20.0F, n2 - 10.0F, 0.0F);
      BufferRenderer.drawWithGlobalProgram(begin.end());
      RenderSystem.disableBlend();
   }

       public static void renderRoundedOutline(
      DrawContext drawContext, Color color, double n, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9, double n10
   ) {
      int rgb = color.getRGB();
      Matrix4f positionMatrix = drawContext.getMatrices().peek().getPositionMatrix();
      setup();
      RenderSystem.setShader(GameRenderer::getPositionColorProgram);
      renderRoundedOutlineInternal(
         positionMatrix,
         (rgb >> 16 & 0xFF) / 255.0F,
         (rgb >> 8 & 0xFF) / 255.0F,
         (rgb & 0xFF) / 255.0F,
         (rgb >> 24 & 0xFF) / 255.0F,
         n,
         n2,
         n3,
         n4,
         n5,
         n6,
         n7,
         n8,
         n9,
         n10
      );
      cleanup();
   }

   public static MatrixStack matrixFrom(double n, double n2, double n3) {
      MatrixStack matrixStack = new MatrixStack();
      Camera camera = MinecraftClient.getInstance().gameRenderer.getCamera();
      matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
      matrixStack.translate(n - camera.getPos().x, n2 - camera.getPos().y, n3 - camera.getPos().z);
      return matrixStack;
   }

   public static void renderQuad(MatrixStack matrixStack, float n, float n2, float n3, float n4, int n5) {
      float n6 = (n5 >> 24 & 0xFF) / 255.0F;
      float n7 = (n5 >> 16 & 0xFF) / 255.0F;
      float n8 = (n5 >> 8 & 0xFF) / 255.0F;
      float n9 = (n5 & 0xFF) / 255.0F;
      matrixStack.push();
      matrixStack.scale(0.5F, 0.5F, 0.5F);
      matrixStack.translate(n, n2, 0.0);
      Tessellator instance = Tessellator.getInstance();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      BufferBuilder begin = instance.begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      begin.vertex(0.0F, 0.0F, 0.0F).color(n7, n8, n9, n6);
      begin.vertex(0.0F, n4, 0.0F).color(n7, n8, n9, n6);
      begin.vertex(n3, n4, 0.0F).color(n7, n8, n9, n6);
      begin.vertex(n3, 0.0F, 0.0F).color(n7, n8, n9, n6);
      BufferRenderer.drawWithGlobalProgram(begin.end());
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void renderRoundedQuadInternal(
      Matrix4f matrix4f,
      float n,
      float n2,
      float n3,
      float n4,
      double n5,
      double n6,
      double n7,
      double n8,
      double n9,
      double n10,
      double n11,
      double n12,
      double n13
   ) {
      BufferBuilder begin = Tessellator.getInstance().begin(DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
      double[][] array = new double[][]{{n7 - n12, n8 - n12, n12}, {n7 - n10, n6 + n10, n10}, {n5 + n9, n6 + n9, n9}, {n5 + n11, n8 - n11, n11}};

      for (int i = 0; i < 4; i++) {
         double[] array2 = array[i];
         double n14 = array2[2];
         double angdeg = i * 90.0;

         while (angdeg < 90.0 + i * 90.0) {
            double radians = Math.toRadians(angdeg);
            begin.vertex(matrix4f, (float)array2[0] + (float)(Math.sin((float)radians) * n14), (float)array2[1] + (float)(Math.cos((float)radians) * n14), 0.0F)
               .color(n, n2, n3, n4);
            angdeg += 90.0 / n13;
         }

         angdeg = Math.toRadians(90.0 + i * 90.0);
         begin.vertex(matrix4f, (float)array2[0] + (float)(Math.sin((float)angdeg) * n14), (float)array2[1] + (float)(Math.cos((float)angdeg) * n14), 0.0F)
            .color(n, n2, n3, n4);
      }

      BufferRenderer.drawWithGlobalProgram(begin.end());
   }

   public static void renderFilledBox(MatrixStack matrixStack, float n, float n2, float n3, float n4, float n5, float n6, Color color) {
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
      RenderSystem.setShader(GameRenderer::getPositionProgram);
      BufferBuilder begin = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n2, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n3);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n6);
      begin.vertex(matrixStack.peek().getPositionMatrix(), n4, n5, n6);
      BufferRenderer.drawWithGlobalProgram(begin.end());
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

   public static void renderLine(MatrixStack matrixStack, Color color, Vec3d vec3d, Vec3d vec3d2) {
      matrixStack.push();
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      if (DonutBBC.enableMSAA.getValue()) {
         GL11.glEnable(32925);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
      }

      GL11.glDepthFunc(519);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableBlend();
      genericAABBRender(
         DrawMode.DEBUG_LINES,
         VertexFormats.POSITION_COLOR,
         GameRenderer::getPositionColorProgram,
         positionMatrix,
         vec3d,
         vec3d2.subtract(vec3d),
         color,
         (bufferBuilder, n, n3, n5, n7, n9, n11, n13, n15, n17, n19, matrix4f) -> {
            bufferBuilder.vertex(matrix4f, n, n3, n5).color(n13, n15, n17, n19);
            bufferBuilder.vertex(matrix4f, n7, n9, n11).color(n13, n15, n17, n19);
         }
      );
      GL11.glDepthFunc(515);
      RenderSystem.disableBlend();
      if (DonutBBC.enableMSAA.getValue()) {
         GL11.glDisable(2848);
         GL11.glDisable(32925);
      }

      matrixStack.pop();
   }

   public static void drawItem(DrawContext drawContext, ItemStack itemStack, int n, int n2, float n3, int n4) {
      if (!itemStack.isEmpty()) {
         float n5 = n3 / 16.0F;
         MatrixStack matrices = drawContext.getMatrices();
         matrices.push();
         matrices.translate(n, n2, n4);
         matrices.scale(n5, n5, 1.0F);
         drawContext.drawItem(itemStack, 0, 0);
         matrices.pop();
      }
   }

   private static void genericAABBRender(
      DrawMode mode,
      VertexFormat format,
      Supplier<ShaderProgram> shader,
      Matrix4f stack,
      Vec3d start,
      Vec3d dimensions,
      Color color,
      RenderUtils.RenderAction action
   ) {
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      float alpha = color.getAlpha() / 255.0F;
      Vec3d end = start.add(dimensions);
      float x1 = (float)start.x;
      float y1 = (float)start.y;
      float z1 = (float)start.z;
      float x2 = (float)end.x;
      float y2 = (float)end.y;
      float z2 = (float)end.z;
      useBuffer(mode, format, shader, bufferBuilder -> action.run(bufferBuilder, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, stack));
   }

   private static void useBuffer(DrawMode vertexFormat$DrawMode, VertexFormat vertexFormat, Supplier<ShaderProgram> shader, Consumer<BufferBuilder> consumer) {
      BufferBuilder begin = Tessellator.getInstance().begin(vertexFormat$DrawMode, vertexFormat);
      consumer.accept(begin);
      setup();
      RenderSystem.setShader(shader);
      BufferRenderer.drawWithGlobalProgram(begin.end());
      cleanup();
   }

   public static int getRainbowColor(int offset, float alpha) {
      float hue = (float)((System.currentTimeMillis() + offset) % 3000L) / 3000.0F;
      return Color.HSBtoRGB(hue, 1.0F, 1.0F) | (int)(alpha * 255.0F) << 24;
   }

   interface RenderAction {
      void run(
         BufferBuilder var1,
         float var2,
         float var3,
         float var4,
         float var5,
         float var6,
         float var7,
         float var8,
         float var9,
         float var10,
         float var11,
         Matrix4f var12
      );
   }
}
