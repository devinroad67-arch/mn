package skid.gypsyy;

import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      new DonutBBC();
   }
}
