package skid.gypsyy.module;

import skid.gypsyy.event.EventListener;
import skid.gypsyy.event.events.KeyEvent;
import skid.gypsyy.gui.ClickGUI;
import skid.gypsyy.module.modules.client.ConfigDebug;
import skid.gypsyy.module.modules.client.DonutBBC;
import skid.gypsyy.module.modules.client.Friends;
import skid.gypsyy.module.modules.client.SelfDestruct;
import skid.gypsyy.module.modules.combat.ElytraSwap;
import skid.gypsyy.module.modules.combat.Hitbox;
import skid.gypsyy.module.modules.combat.MaceSwap;
import skid.gypsyy.module.modules.combat.StaticHitboxes;
import skid.gypsyy.module.modules.crystal.AnchorMacro;
import skid.gypsyy.module.modules.crystal.AutoCrystal;
import skid.gypsyy.module.modules.crystal.AutoHitCrystal;
import skid.gypsyy.module.modules.crystal.AutoInventoryTotem;
import skid.gypsyy.module.modules.crystal.AutoTotem;
import skid.gypsyy.module.modules.crystal.DoubleAnchor;
import skid.gypsyy.module.modules.crystal.HoverTotem;
import skid.gypsyy.module.modules.donut.AntiTrap;
import skid.gypsyy.module.modules.donut.AuctionSniper;
import skid.gypsyy.module.modules.donut.AutoSell;
import skid.gypsyy.module.modules.donut.AutoSpawnerSell;
import skid.gypsyy.module.modules.donut.BoneDropper;
import skid.gypsyy.module.modules.donut.NetheriteFinder;
import skid.gypsyy.module.modules.donut.RTPEndBaseFinder;
import skid.gypsyy.module.modules.donut.RtpBaseFinder;
import skid.gypsyy.module.modules.donut.ShulkerDropper;
import skid.gypsyy.module.modules.donut.SpawnerProtect;
import skid.gypsyy.module.modules.donut.TunnelBaseFinder;
import skid.gypsyy.module.modules.misc.AutoEat;
import skid.gypsyy.module.modules.misc.AutoFirework;
import skid.gypsyy.module.modules.misc.AutoMine;
import skid.gypsyy.module.modules.misc.AutoTPA;
import skid.gypsyy.module.modules.misc.AutoTool;
import skid.gypsyy.module.modules.misc.CordSnapper;
import skid.gypsyy.module.modules.misc.ElytraGlide;
import skid.gypsyy.module.modules.misc.FastPlace;
import skid.gypsyy.module.modules.misc.Freecam;
import skid.gypsyy.module.modules.misc.KeyPearl;
import skid.gypsyy.module.modules.misc.NameProtect;
import skid.gypsyy.module.modules.misc.PearlBoost;
import skid.gypsyy.module.modules.misc.QuickMacro;
import skid.gypsyy.module.modules.misc.TridentBoost;
import skid.gypsyy.module.modules.misc.WeatherNotifier;
import skid.gypsyy.module.modules.movement.FakeLag;
import skid.gypsyy.module.modules.render.Animations;
import skid.gypsyy.module.modules.render.BlockEsp;
import skid.gypsyy.module.modules.render.FullBright;
import skid.gypsyy.module.modules.render.HUD;
import skid.gypsyy.module.modules.render.KelpESP;
import skid.gypsyy.module.modules.render.NoRender;
import skid.gypsyy.module.modules.render.PlayerESP;
import skid.gypsyy.module.modules.render.ScoreboardModule;
import skid.gypsyy.module.modules.render.StorageESP;
import skid.gypsyy.module.modules.render.SwingSpeed;
import skid.gypsyy.module.modules.render.TargetHUD;
import skid.gypsyy.module.modules.render.TridentESP;
import skid.gypsyy.module.setting.BindSetting;
import skid.gypsyy.utils.EncryptedString;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.screen.ChatScreen;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();

   public ModuleManager() {
      this.keyCodec();
      this.d();
   }

   public void keyCodec() {
      this.add(new ElytraSwap());
      this.add(new Hitbox());
      this.add(new MaceSwap());
      this.add(new StaticHitboxes());
      this.add(new ConfigDebug());
      this.add(new DonutBBC());
      this.add(new SelfDestruct());
      this.add(new Friends());
      this.add(new Animations());
      this.add(new FullBright());
      this.add(new HUD());
      this.add(new KelpESP());
      this.add(new NoRender());
      this.add(new PlayerESP());
      this.add(new StorageESP());
      this.add(new SwingSpeed());
      this.add(new TargetHUD());
      this.add(new TridentESP());
      this.add(new ScoreboardModule());
      this.add(new BlockEsp());
      this.add(new AutoEat());
      this.add(new AutoFirework());
      this.add(new AutoMine());
      this.add(new AutoTPA());
      this.add(new AutoTool());
      this.add(new CordSnapper());
      this.add(new ElytraGlide());
      this.add(new FastPlace());
      this.add(new Freecam());
      this.add(new KeyPearl());
      this.add(new NameProtect());
      this.add(new WeatherNotifier());
      this.add(new TridentBoost());
      this.add(new PearlBoost());
      this.add(new AnchorMacro());
      this.add(new AutoCrystal());
      this.add(new AutoHitCrystal());
      this.add(new AutoInventoryTotem());
      this.add(new AutoTotem());
      this.add(new DoubleAnchor());
      this.add(new HoverTotem());
      this.add(new AntiTrap());
      this.add(new AuctionSniper());
      this.add(new AutoSell());
      this.add(new AutoSpawnerSell());
      this.add(new BoneDropper());
      this.add(new NetheriteFinder());
      this.add(new RtpBaseFinder());
      this.add(new RTPEndBaseFinder());
      this.add(new ShulkerDropper());
      this.add(new TunnelBaseFinder());
      this.add(new SpawnerProtect());
      this.add(new FakeLag());
      this.add(new QuickMacro());
      Friends a = Friends.getInstance();
      a.setEnabled(true);
   }

   public List<Module> elementCodec() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      skid.gypsyy.DonutBBC.INSTANCE.getEventBus().register(this);

      for (Module next : this.modules) {
         next.addsetting(
            new BindSetting(EncryptedString.of("Keybind"), next.getKeybind(), true).setDescription(EncryptedString.of("Key to enabled the module"))
         );
      }
   }

   public List<Module> keyCodec(Category category) {
      return this.modules.stream().filter(module -> module.getCategory() == category).toList();
   }

   public Module getModuleByClass(Class<? extends Module> obj) {
      return this.modules.stream().filter(obj::isInstance).findFirst().orElse(null);
   }

   public void add(Module module) {
      skid.gypsyy.DonutBBC.INSTANCE.getEventBus().register(module);
      this.modules.add(module);
   }

   @EventListener
   public void keyCodec(KeyEvent keyEvent) {
      if (skid.gypsyy.DonutBBC.mc.player != null && !(skid.gypsyy.DonutBBC.mc.currentScreen instanceof ChatScreen)) {
         if (!(skid.gypsyy.DonutBBC.mc.currentScreen instanceof ClickGUI)) {
            this.modules.forEach(module -> {
               if (module.getKeybind() == keyEvent.key && keyEvent.mode == 1) {
                  if (module instanceof SelfDestruct && SelfDestruct.isActive) {
                     return;
                  }

                  if (module instanceof DonutBBC && SelfDestruct.hasSelfDestructed) {
                     return;
                  }

                  module.toggle();
               }
            });
         }
      }
   }
}
