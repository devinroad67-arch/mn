package skid.gypsyy.module.modules.misc;

import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.module.setting.Setting;
import skid.gypsyy.module.setting.StringSetting;
import skid.gypsyy.utils.EncryptedString;

public class NameProtect extends Module {
   private final StringSetting fakeName = new StringSetting("Fake Name", "Player");

   public NameProtect() {
      super(EncryptedString.of("Name Protect"), EncryptedString.of("Replaces your name with given one."), -1, Category.MISC);
      this.addsettings(new Setting[]{this.fakeName});
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   public String getFakeName() {
      return this.fakeName.getValue();
   }
}
