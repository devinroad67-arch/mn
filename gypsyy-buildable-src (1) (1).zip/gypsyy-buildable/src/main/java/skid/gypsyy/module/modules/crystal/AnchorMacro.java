package skid.gypsyy.module.modules.crystal;

import skid.gypsyy.event.EventListener;
import skid.gypsyy.event.events.TickEvent;
import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.module.setting.NumberSetting;
import skid.gypsyy.module.setting.Setting;
import skid.gypsyy.utils.BlockUtil;
import skid.gypsyy.utils.EncryptedString;
import skid.gypsyy.utils.InventoryUtil;
import skid.gypsyy.utils.KeyUtils;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.hit.BlockHitResult;
import org.lwjgl.glfw.GLFW;

public final class AnchorMacro extends Module {
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
   private final NumberSetting glowstoneDelay = new NumberSetting(EncryptedString.of("Glowstone Delay"), 0.0, 20.0, 0.0, 1.0);
   private final NumberSetting explodeDelay = new NumberSetting(EncryptedString.of("Explode Delay"), 0.0, 20.0, 0.0, 1.0);
   private final NumberSetting totemSlot = new NumberSetting(EncryptedString.of("Totem Slot"), 1.0, 9.0, 1.0, 1.0);
   private int keybind = 0;
   private int glowstoneDelayCounter = 0;
   private int explodeDelayCounter = 0;

   public AnchorMacro() {
      super(EncryptedString.of("Anchor Macro"), EncryptedString.of("Automatically blows up respawn anchors for you"), -1, Category.CRYSTAL);
      this.addsettings(new Setting[]{this.switchDelay, this.glowstoneDelay, this.explodeDelay, this.totemSlot});
   }

   @Override
   public void onEnable() {
      this.resetCounters();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent tickEvent) {
      if (this.mc.currentScreen == null) {
         if (!this.isShieldOrFoodActive()) {
            if (KeyUtils.isKeyPressed(1)) {
               this.handleAnchorInteraction();
            }
         }
      }
   }

   private boolean isShieldOrFoodActive() {
      boolean isFood = this.mc.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)
         || this.mc.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD);
      boolean isShield = this.mc.player.getMainHandStack().getItem() instanceof ShieldItem || this.mc.player.getOffHandStack().getItem() instanceof ShieldItem;
      boolean isRightClickPressed = GLFW.glfwGetMouseButton(this.mc.getWindow().getHandle(), 1) == 1;
      return (isFood || isShield) && isRightClickPressed;
   }

   private void handleAnchorInteraction() {
      if (this.mc.crosshairTarget instanceof BlockHitResult blockHitResult) {
         if (BlockUtil.isBlockAtPosition(blockHitResult.getBlockPos(), Blocks.RESPAWN_ANCHOR)) {
            this.mc.options.useKey.setPressed(false);
            if (BlockUtil.isRespawnAnchorUncharged(blockHitResult.getBlockPos())) {
               this.placeGlowstone(blockHitResult);
            } else if (BlockUtil.isRespawnAnchorCharged(blockHitResult.getBlockPos())) {
               this.explodeAnchor(blockHitResult);
            }
         }
      }
   }

   private void placeGlowstone(BlockHitResult blockHitResult) {
      if (!this.mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.keybind < this.switchDelay.getIntValue()) {
            this.keybind++;
            return;
         }

         this.keybind = 0;
         InventoryUtil.swap(Items.GLOWSTONE);
      }

      if (this.mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.glowstoneDelayCounter < this.glowstoneDelay.getIntValue()) {
            this.glowstoneDelayCounter++;
            return;
         }

         this.glowstoneDelayCounter = 0;
         BlockUtil.interactWithBlock(blockHitResult, true);
      }
   }

   private void explodeAnchor(BlockHitResult blockHitResult) {
      int selectedSlot = this.totemSlot.getIntValue() - 1;
      if (this.mc.player.getInventory().selectedSlot != selectedSlot) {
         if (this.keybind < this.switchDelay.getIntValue()) {
            this.keybind++;
            return;
         }

         this.keybind = 0;
         this.mc.player.getInventory().selectedSlot = selectedSlot;
      }

      if (this.mc.player.getInventory().selectedSlot == selectedSlot) {
         if (this.explodeDelayCounter < this.explodeDelay.getIntValue()) {
            this.explodeDelayCounter++;
            return;
         }

         this.explodeDelayCounter = 0;
         BlockUtil.interactWithBlock(blockHitResult, true);
      }
   }

   private void resetCounters() {
      this.keybind = 0;
      this.glowstoneDelayCounter = 0;
      this.explodeDelayCounter = 0;
   }
}
