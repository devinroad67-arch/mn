package skid.gypsyy.module.modules.combat;

import skid.gypsyy.event.EventListener;
import skid.gypsyy.event.events.TargetPoseEvent;
import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.utils.EncryptedString;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;

public final class StaticHitboxes extends Module {
   public StaticHitboxes() {
      super(EncryptedString.of("Static HitBoxes"), EncryptedString.of("Expands a Player's Hitbox"), -1, Category.COMBAT);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTargetPose(TargetPoseEvent targetPoseEvent) {
      if (this.isEnabled() && targetPoseEvent.entity instanceof PlayerEntity && !((PlayerEntity)targetPoseEvent.entity).isMainPlayer()) {
         targetPoseEvent.cir.setReturnValue(EntityPose.STANDING);
      }
   }
}
