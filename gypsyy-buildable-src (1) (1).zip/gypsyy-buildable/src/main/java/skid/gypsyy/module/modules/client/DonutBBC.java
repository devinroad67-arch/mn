package skid.gypsyy.module.modules.client;

import skid.gypsyy.event.EventListener;
import skid.gypsyy.event.events.PacketReceiveEvent;
import skid.gypsyy.gui.ClickGUI;
import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.module.setting.BooleanSetting;
import skid.gypsyy.module.setting.ModeSetting;
import skid.gypsyy.module.setting.NumberSetting;
import skid.gypsyy.module.setting.Setting;
import skid.gypsyy.utils.EncryptedString;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;

public final class DonutBBC extends Module {
   public static DonutBBC instance;
   public static final NumberSetting redColor = new NumberSetting(EncryptedString.of("Red"), 0.0, 255.0, 166.0, 1.0);
   public static final NumberSetting greenColor = new NumberSetting(EncryptedString.of("Green"), 0.0, 255.0, 63.0, 1.0);
   public static final NumberSetting blueColor = new NumberSetting(EncryptedString.of("Blue"), 0.0, 255.0, 255.0, 1.0);
   public static final NumberSetting windowAlpha = new NumberSetting(EncryptedString.of("Window Alpha"), 0.0, 255.0, 93.0, 1.0);
   public static final BooleanSetting enableBreathingEffect = new BooleanSetting(EncryptedString.of("Breathing"), false)
      .setDescription(EncryptedString.of("Color breathing effect (only with rainbow off)"));
   public static final BooleanSetting enableRainbowEffect = new BooleanSetting(EncryptedString.of("Rainbow"), false)
      .setDescription(EncryptedString.of("Enables LGBTQ mode"));
   public static final BooleanSetting renderBackground = new BooleanSetting(EncryptedString.of("Background"), true)
      .setDescription(EncryptedString.of("Renders the background of the Click Gui"));
   public static final BooleanSetting useCustomFont = new BooleanSetting(EncryptedString.of("Custom Font"), true);
   private final BooleanSetting preventClose = new BooleanSetting(EncryptedString.of("Prevent Close"), true)
      .setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final NumberSetting cornerRoundness = new NumberSetting(EncryptedString.of("Roundness"), 1.0, 10.0, 8.0, 1.0);
   public static final ModeSetting<DonutBBC.AnimationMode> animationMode = new ModeSetting<>(
      EncryptedString.of("Animations"), DonutBBC.AnimationMode.NORMAL, DonutBBC.AnimationMode.class
   );
   public static final BooleanSetting enableMSAA = new BooleanSetting(EncryptedString.of("MSAA"), true)
      .setDescription(EncryptedString.of("Anti Aliasing | This can impact performance if you're using tracers but gives them a smoother look |"));
   public static final BooleanSetting Gui = new BooleanSetting(EncryptedString.of("Open GUI"), false).setDescription(EncryptedString.of("Open GUI"));
   public static final NumberSetting guiScale = new NumberSetting(EncryptedString.of("GUI Scale"), 0.5, 2.0, 1.0, 0.1)
      .setDescription(EncryptedString.of("Scale factor for the GUI size"));
   public boolean shouldPreventClose;

   public DonutBBC() {
      super(EncryptedString.of("Gypsyy"), EncryptedString.of("Settings for the client"), 344, Category.CLIENT);
      this.addsettings(
         new Setting[]{
            redColor, greenColor, blueColor, windowAlpha, renderBackground, this.preventClose, cornerRoundness, animationMode, enableMSAA, Gui, guiScale
         }
      );
      instance = this;
   }

   @Override
   public void onEnable() {
      if (!SelfDestruct.hasSelfDestructed) {
         skid.gypsyy.DonutBBC.INSTANCE.screen = this.mc.currentScreen;
         if (skid.gypsyy.DonutBBC.INSTANCE.GUI != null) {
            this.mc.setScreenAndRender(skid.gypsyy.DonutBBC.INSTANCE.GUI);
         } else if (this.mc.currentScreen instanceof InventoryScreen) {
            this.shouldPreventClose = true;
         }

         if (new Random().nextInt(3) == 1) {
            CompletableFuture.runAsync(() -> {});
         }

         super.onEnable();
      }
   }

   @Override
   public void onDisable() {
      if (this.mc.currentScreen instanceof ClickGUI) {
         skid.gypsyy.DonutBBC.INSTANCE.GUI.close();
         this.mc.setScreenAndRender(skid.gypsyy.DonutBBC.INSTANCE.screen);
         skid.gypsyy.DonutBBC.INSTANCE.GUI.onGuiClose();
      } else if (this.mc.currentScreen instanceof InventoryScreen) {
         this.shouldPreventClose = false;
      }

      super.onDisable();
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
      if (this.shouldPreventClose && packetReceiveEvent.packet instanceof OpenScreenS2CPacket && this.preventClose.getValue()) {
         packetReceiveEvent.cancel();
      }
   }

   public static boolean OpenGui() {
      return Gui.getValue();
   }

   public static enum AnimationMode {
      NORMAL("Normal", 0),
      POSITIVE("Positive", 1),
      OFF("Off", 2);

      private AnimationMode(final String name, final int ordinal) {
      }

      public static DonutBBC getInstance() {
         if (DonutBBC.instance == null) {
            DonutBBC.instance = new DonutBBC();
         }

         return DonutBBC.instance;
      }
   }
}
