package skid.gypsyy.module.modules.misc;

import skid.gypsyy.event.EventListener;
import skid.gypsyy.event.events.TickEvent;
import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.module.setting.BindSetting;
import skid.gypsyy.module.setting.Setting;
import skid.gypsyy.module.setting.StringSetting;
import skid.gypsyy.utils.EncryptedString;
import skid.gypsyy.utils.KeyUtils;
import skid.gypsyy.utils.embed.DiscordWebhook;
import java.util.concurrent.CompletableFuture;

public final class CordSnapper extends Module {
   private final BindSetting activateKey = new BindSetting(EncryptedString.of("Activate Key"), -1, false);
   private final StringSetting webhookUrl = new StringSetting(EncryptedString.of("Webhook"), "");
   private int cooldownCounter = 0;

   public CordSnapper() {
      super(EncryptedString.of("Cord Snapper"), EncryptedString.of("Sends base coordinates to discord webhook"), -1, Category.MISC);
      this.addsettings(new Setting[]{this.activateKey, this.webhookUrl});
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player != null) {
         if (this.cooldownCounter > 0) {
            this.cooldownCounter--;
         } else {
            if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
               DiscordWebhook embedSender = new DiscordWebhook(this.webhookUrl.value);
               embedSender.setContent("Coordinates: x: " + this.mc.player.getX() + " y: " + this.mc.player.getY() + " z: " + this.mc.player.getZ());
               CompletableFuture.runAsync(() -> {
                  try {
                     embedSender.execute();
                  } catch (Throwable var2x) {
                     var2x.printStackTrace(System.err);
                  }
               });
               this.cooldownCounter = 40;
            }
         }
      }
   }
}
