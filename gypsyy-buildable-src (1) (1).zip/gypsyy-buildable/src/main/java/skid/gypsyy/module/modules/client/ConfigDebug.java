package skid.gypsyy.module.modules.client;

import skid.gypsyy.DonutBBC;
import skid.gypsyy.module.Category;
import skid.gypsyy.module.Module;
import skid.gypsyy.module.setting.BooleanSetting;
import skid.gypsyy.module.setting.NumberSetting;
import skid.gypsyy.module.setting.Setting;
import skid.gypsyy.module.setting.StringSetting;
import skid.gypsyy.utils.EncryptedString;

public final class ConfigDebug extends Module {
   private final BooleanSetting testBoolean = new BooleanSetting(EncryptedString.of("Test Boolean"), false)
      .setDescription(EncryptedString.of("Test boolean setting"));
   private final NumberSetting testNumber = new NumberSetting(EncryptedString.of("Test Number"), 1.0, 100.0, 50.0, 1.0)
      .setDescription(EncryptedString.of("Test number setting"));
   private final StringSetting testString = new StringSetting(EncryptedString.of("Test String"), "Default Value")
      .setDescription(EncryptedString.of("Test string setting"));

   public ConfigDebug() {
      super(EncryptedString.of("Config Debug"), EncryptedString.of("Debug module for testing config saving"), -1, Category.CLIENT);
      this.addsettings(new Setting[]{this.testBoolean, this.testNumber, this.testString});
   }

   @Override
   public void onEnable() {
      System.out.println("[ConfigDebug] Module enabled - testing config saving...");
      this.testBoolean.setValue(true);
      this.testNumber.getValue(75.0);
      this.testString.setValue("Test Value Changed");
      DonutBBC.INSTANCE.getConfigManager().manualSave();
      System.out.println("[ConfigDebug] Config save test completed. Check console for results.");
      this.toggle();
   }

   @Override
   public void onDisable() {
   }
}
